import random


class CustomAgent:
    """
    Example random agent. Replace takeAction() with your own logic.

    Your agent will be instantiated once and reused across games.
    """

    def takeAction(self, state):
        """
        Select an action for the given game state.

        Parameters:
            state : State
                Current game state. Key methods/attributes:
                  state.getActions()  -> list of legal actions
                  state.player        -> 0 (MAX player) or 1 (MIN player)
                  state.takeAction(a) -> new State after applying action a
                  state.isTerminal()  -> True if game is over
                  state.getValue()    -> terminal value (+1 / -1 / 0)
                  state.Evaluate()    -> heuristic score estimate

        Returns:
            action : one element from state.getActions()
        """
        actions = state.getActions()
        if not actions:
            return None
        return random.choice(actions)
